COPY RABBIT

by _ = F = _



Platforming Puzzle Game.
Created for the event "제 1회 KGMC Education잼".

1. Controls
- Movement : A, W, D  or  ←, ↑, →
- Restart : R
- Copy pattern : SPACE
- Teleportation : Mouse R+L Button
- ♥ : Ctrl

2. My Works
- https://twitter.com/1F_works
- https://gamejolt.com/@F_works
- https://f-works.itch.io/

Good night. ;)